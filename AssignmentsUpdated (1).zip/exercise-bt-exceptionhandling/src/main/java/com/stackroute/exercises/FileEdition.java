package com.stackroute.exercises;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class FileEdition {
    //Write here logic to append the given content in the given file name
    public String fileEditor(String fileName, String content) {
    	if (content==null || content.length()<1 || content.trim().isEmpty()) {
    		return "Given content to add is empty,null or blank space";
    	}
    	try {
			FileWriter wrt = new FileWriter(fileName);
			wrt.write(content);
			wrt.close();
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            // Closing the connection
           return br.readLine();
		}
    	catch (FileNotFoundException e) {
    		return "File '"+fileName+"' not Found";
    	}
    	catch (IOException e) {
			return "File '"+fileName+"' not Found.";
		}
    }
}