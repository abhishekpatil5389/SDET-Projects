package com.stackroute.exception;
public class NegativeIntegerException extends Exception {

	private static final long serialVersionUID = 1223339214865992108L;
	public NegativeIntegerException() {
		super();
	}
}