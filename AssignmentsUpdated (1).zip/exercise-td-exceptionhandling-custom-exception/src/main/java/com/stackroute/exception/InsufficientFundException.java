package com.stackroute.exception;

public class InsufficientFundException extends Exception {

	private static final long serialVersionUID = -769639590046092628L;
//	public InsufficientFundException() {
//		super();
//	}

}