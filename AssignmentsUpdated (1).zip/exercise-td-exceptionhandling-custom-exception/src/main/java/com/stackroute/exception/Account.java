package com.stackroute.exception;

public class Account {
	private int accountBalance;

	public Account(int accountBalance) {
		this.accountBalance = accountBalance;
	}

	public Account() {
		 // This constructor is intentionally empty. Nothing special is needed here.
	}

	public int getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}

	public double withdraw(int money) throws NegativeIntegerException, InsufficientFundException {
		
		if (money<0) {
			throw new NegativeIntegerException();
		}
		else if (money>this.accountBalance) {
			throw new InsufficientFundException();
		}
		return this.accountBalance-money;
	}
	
	

}