package com.stackroute.oops;

public interface Vehicle {
   abstract int maxSpeed(String type);
}
