package com.stackroute.commonjavaclasses;

public class ISBNValidator {

	public Integer validateISBNNumber(String string) {
		// TODO Auto-generated method stub
		if(string.isEmpty()) {
			return -1;
		}
		final double dec = Double.parseDouble(string);
		char []charray = string.toCharArray();
		int j = 10;
		int sum = 0;
		for(char chr:charray) {
			
			sum += (int)chr *j--;
		}
		if(sum%11==0) {
			return 1;
		}
		else {
			return 0;
		}
		
	}

}