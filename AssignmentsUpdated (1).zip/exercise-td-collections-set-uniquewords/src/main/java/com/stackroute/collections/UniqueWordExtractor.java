package com.stackroute.collections;

import java.util.Set;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeSet;

import com.stackroute.collections.UniqueWordExtractor.SortOrder;

public class UniqueWordExtractor {
	enum SortOrder{
		INPUT_ORDER,
		ALPHABETIC_ASCENDING,
		ALPHABETIC_DESCENDING,
		LENGTH_THEN_ALPHABETIC_ASCENDING
	}

	public Set<String> fetchUniqueWordsInOrder(String paragraph, Object object) {
		
		if (paragraph==null) {
			Set<String> empty = new LinkedHashSet<String>();
			return empty;
		}
		paragraph = paragraph.replaceAll("\\p{Punct}", "");
		String strArray[] = paragraph.split(" ");
	 if (object==null ||  object == SortOrder.INPUT_ORDER) {
			Set<String> set = new LinkedHashSet<>(Arrays.asList(strArray));
			return set;
	    }
	else if (object == SortOrder.ALPHABETIC_ASCENDING) {
		Set<String> set = new TreeSet<>(Arrays.asList(strArray));
		return set;
	}

	else if (object == SortOrder.ALPHABETIC_DESCENDING) {
		TreeSet<String> set = new TreeSet<>(Arrays.asList(strArray));
		NavigableSet<String> reverseSet = set.descendingSet();
		return reverseSet;
	}
	else if (object == SortOrder.LENGTH_THEN_ALPHABETIC_ASCENDING) {
		Set<String> set = new TreeSet<>(Arrays.asList(strArray));
		return set;
	}
		return null;
	}

}
