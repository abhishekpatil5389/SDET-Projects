package com.stackroute.streams;

import java.util.List;

public class BatsmanService {



	public Object getBatsmanNamesForCountry(List<Batsman> batsmanList, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getBatsman(List<Batsman> batsmanList, String string, String string2) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getPlayerNameWithTotalRuns(List<Batsman> batsmanList) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getHighestRunsScoredByBatsman(List<Batsman> batsmanList, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getPlayerNamesByCountry(List<Batsman> batsmanList, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
