package com.stackroute.oops;

public interface Shape {
	
double getArea();
double getPerimeter();
}
