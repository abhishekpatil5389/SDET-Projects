package com.stackroute.collections;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasProperty;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class StudentTests {
    private static final String MESSAGE_ONE = "Student properties are not set correctly in the constructor";
    private static final String MESSAGE_TWO = "Student details returned by toString() are not correct";
    private Student student;

    @BeforeEach
    public void setUp() {
        student = new Student(1001, "Punith", 84.5);
    }

    @AfterEach
    public void tearDown() {
        student = null;
    }

    @Test
    public void givenValidStudentValuesWhenCreatedThenSetProperties() {
        assertThat(MESSAGE_ONE, student, hasProperty("studentName", is("Punith")));
        assertThat(MESSAGE_ONE, student, hasProperty("studentId", is(1001)));
        assertThat(MESSAGE_ONE, student, hasProperty("cgpa", is(84.5)));
    }

    @Test
    public void givenValidStudentValuesThenReturnStudentDetails() {
        String details = student.toString();
        assertTrue(details.contains("studentId=1001, studentName=Punith, cgpa=84.5"), MESSAGE_TWO);
    }

}
