package com.stackroute.collections;

import org.hamcrest.collection.IsIterableContainingInOrder;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Comparator;
import java.util.TreeSet;

import static org.hamcrest.MatcherAssert.assertThat;

public class StudentCgpaComparatorTests {
    private static final String MESSAGE_ONE = "StudentCgpaComparator should be of comparator type";
    private static final String MESSAGE_TWO = "Student list returned has not sorted student's CGPA in the descending order";
    TreeSet<Student> sortedSet;

    @BeforeEach
    public void setUp(){
        sortedSet=new TreeSet<>(new StudentCgpaComparator());
    }

    @AfterEach
    public void tearDown() {
        sortedSet = null;
    }

    @Test
    public void givenPlayerNameComparatorClassThenShouldBeOfComparatorType() {
        Assertions.assertTrue(Comparator.class.isAssignableFrom(StudentCgpaComparator.class), MESSAGE_ONE);
    }

    @Test
    public void givenStudentValuesThenReturnSortedSetByCGPAInDescendingOrder() {
        Student studentOne = new Student(1001, "Punith", 44.5);
        Student studentTwo = new Student(1002, "Abhirami", 80.2);
        Student studentThree = new Student(1003, "Chandan", 67.3);
        sortedSet.add(studentOne);
        sortedSet.add(studentTwo);
        sortedSet.add(studentThree);
        assertThat(MESSAGE_TWO, sortedSet, IsIterableContainingInOrder.contains(studentTwo, studentThree, studentOne));
    }

    @Test
    public void givenStudentValuesWhenCGPAAreSameThenReturnSortedSetByIdInAscendingOrder() {
        Student studentOne = new Student(1001, "Punith", 67.3);
        Student studentTwo = new Student(1002, "Abhirami", 80.2);
        Student studentThree = new Student(1003, "Chandan", 67.3);
        sortedSet.add(studentOne);
        sortedSet.add(studentTwo);
        sortedSet.add(studentThree);
        assertThat(MESSAGE_TWO, sortedSet, IsIterableContainingInOrder.contains(studentTwo, studentOne, studentThree));
    }
}
