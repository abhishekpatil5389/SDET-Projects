package com.stackroute.basics;

import java.math.BigInteger;
import java.util.Scanner;

public class NumberValidation {
    public static void main(String[] args) {
        new NumberValidation().inputValidator();
    }

    //write logic to get input from user and send it to numberValidator in BigInteger
    public void inputValidator() {
	Scanner scn= new Scanner(System.in);
	double num=scn.nextDouble();
	if (num==0 || num%1!=0){
		System.out.println("Give proper whole number which is not zero");
	}
	
	else{
	BigInteger anum = BigInteger.valueOf((long)num);
	System.out.println("The number is "+numberValidator(anum));
	}
	scn.close();
    }

    //write logic to find even/odd and return string
    public String numberValidator(BigInteger number) {
	BigInteger anum = number.mod(BigInteger.valueOf(2));
	int res= anum.compareTo(BigInteger.valueOf(0));
	return  (res==0)?"even":"odd";
        
    }
}
